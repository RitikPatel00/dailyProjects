package com.sapient.dao;


import com.sapient.app.SpringBootTestApplication;
import com.sapient.model.Employee;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.Instant;
import java.util.List;
import static org.hamcrest.CoreMatchers.is;


@ExtendWith(SpringExtension.class)
@DataJpaTest
@ContextConfiguration(classes = {SpringBootTestApplication.class })
//@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
public class DaoTest {

  @Autowired
  EmployeeRepository employeeRepository;

  @BeforeEach
  public void setup() {
    Employee employee = new Employee(null, "steve", "smith");
    Employee savedEmployee = employeeRepository.save(employee);
  }


  @Test
  public void testCreateReadDelete() {
    Employee employee = new Employee(null,"Lokesh", "Gupta");

    Employee savedEmployee= employeeRepository.save(employee);

    Assertions.assertThat(savedEmployee).usingRecursiveComparison()
            .ignoringFields("id").isEqualTo(employee);

    List<Employee> employees = employeeRepository.findAll();

//    Assertions.assertThat(employees).extracting(Employee::getFirstName).containsOnly("Lokesh");
//
//    Assertions.assertThat(employees).size();

    Assertions.assertThat(employees)
            .hasSize(2);
//            .extracting(employees.get(1).getFirstName())
//            .contains("Lokesh");


    Assertions.assertThat(employees).first().hasFieldOrPropertyWithValue("firstName", "steve");


//    employeeRepository.deleteAll();
//    Assertions.assertThat(employeeRepository.findAll()).isEmpty();
  }
}
