package com.sapient.app;

import com.sapient.controller.EmployeeController;
import com.sapient.service.EmployeeService;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.Assertions.*;
import org.assertj.core.api.ObjectAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@ActiveProfiles("test")
class SpringBootTestApplicationTests {

	@Autowired
	EmployeeController employeeController;

	@Test
	public void contextLoads() {
		Assertions.assertThat(employeeController).isNotNull();
	}


}
