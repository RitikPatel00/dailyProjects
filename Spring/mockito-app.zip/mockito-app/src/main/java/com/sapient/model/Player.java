package com.sapient.model;

public class Player {
    private String weapon;

    public Player(String weapon) {

        this.weapon = weapon;
    }
   public String getWeapon() {
        return weapon;
    }
}